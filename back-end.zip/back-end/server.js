const express = require('express')
const cors = require('cors')
const serverlessExpress = require('@vendia/serverless-express')

const app = express()

app.use(cors())
app.get('/', (req, res) => {
  res.send('Hello World!')
})

app.listen(3001, () => {
  console.log('Example app listening on port')
})

exports.handler = serverlessExpress({ app });
